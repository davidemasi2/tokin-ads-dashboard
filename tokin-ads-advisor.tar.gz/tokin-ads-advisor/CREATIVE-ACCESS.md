# Creative Access — portable, zero local dependencies

> This is the single contract for resolving **any** Tokin' Jew / Tokin Chews ad or
> organic creative. It works for **any user on any machine** (Claude Code, Claude.ai
> Skills, ChatGPT Custom GPT, a teammate's laptop) because everything resolves to a
> **public URL**. Never depend on a local path like `~/Documents/.../tokin ads/...`.

## Base URL (public, permanent, free)

```
https://davidemasi2.github.io/tokin-ads-dashboard/
```

Alternate host for the exact same files (use if GH Pages is ever slow):
```
https://raw.githubusercontent.com/davidemasi2/tokin-ads-dashboard/main/
```

Do **not** use `tokin-ads-dashboard-production.up.railway.app` — it is a partial,
stale mirror (ad assets only). GH Pages has full coverage and is the source of truth.

## How to resolve a creative

Every creative path stored in the DB (`meta_offline_ads`) or in
`data/creative_enriched.json` is a **relative path**. Prepend the base URL to get a
working public URL:

| Field | What it is | Example relative value | Resolved URL |
|---|---|---|---|
| `thumb` | small thumbnail | `thumbnails_med/vid_<id>_thumb.jpg` | base + value |
| `thumb_med` | **medium — use this for inline display** | `thumbnails_med/adimg_<…>.jpg` | base + value |
| `thumb_full` | full-res (**PUBLIC** — not local-only) | `fullres/adimg_<…>.jpg` | base + value |
| `video_path` | mp4 (153 videos hosted) | `videos/vid_<id>.mp4` | base + value |
| `video_thumb_path` | video poster frame | `thumbnails/vthumb_<…>.jpg` | base + value |

Organic IG/FB posts (`meta_organic_posts`): `ig_thumbnails_med/<post_id>.webp`
(1,713 hosted). Use `permalink` for the clickable post; the `.webp` for inline.

Dashboards (interactive): `index.html`, `creative_breakdown.html`,
`organic_breakdown.html` under the same base.

Embed inline with markdown so the user sees the creative:
```markdown
![ad](https://davidemasi2.github.io/tokin-ads-dashboard/thumbnails_med/vid_3920021211582453_thumb.jpg)
```

## Real vs. placeholder — ALWAYS gate on this

An ad has a **real, renderable creative iff** its `thumb_med` starts with
`thumbnails_med/`. Equivalently, in `creative_enriched.json` use the
`creative_status` field (`"real"` | `"placeholder"`).

- **689 / 721 ads are `real`.**
- **32 ads are `placeholder`** — their `thumb_med` still points at a 0.7–2.3 KB
  Meta stub under `thumbnails/<adid>_<hash>.jpg`. No real poster was ever archived
  and the Meta CDN/token paths are dead. **Do not render the placeholder** — say
  "no creative archived for this ad" and cite copy/metrics instead. The full list is
  in `THUMBNAIL_BACKFILL_2026-06-29.md` (host repo); recover them later with a fresh
  Meta token or the Meta Ads MCP.

SQL predicate:
```sql
-- only ads with a real creative
WHERE thumb_med LIKE 'thumbnails_med/%'
```

## Notes

- 99→119 of the originally-broken set are now `fmt='video'`: 20 ads Meta returned as
  `image` were actually video creatives (video-view insights) and were reclassified;
  their `video_id` is now populated.
- The full-res posters (`fullres/vid_<id>_thumb.jpg`, ~170–270 KB) are committed and
  hosted — they are **not** local-only.
- `data/creative_enriched.json` is committed to the host repo, so any skill can fetch
  the full enriched dataset from the raw URL above with no local files.
