# Creative Access — portable, zero local dependencies

> This is the single contract for resolving **any** Tokin' Jew / Tokin Chews ad or
> organic creative. It works for **any user on any machine** (Claude Code, Claude.ai
> Skills, ChatGPT Custom GPT, a teammate's laptop) because everything resolves to a
> **public URL**. Never depend on a local path like `~/Documents/.../tokin ads/...`.

## Base URL (public, permanent, free)

```
https://davidemasi2.github.io/tokin-ads-dashboard/
```

Alternate host for the exact same files (use if GH Pages is ever slow):
```
https://raw.githubusercontent.com/davidemasi2/tokin-ads-dashboard/main/
```

Do **not** use `tokin-ads-dashboard-production.up.railway.app` — it is a partial,
stale mirror (ad assets only). GH Pages has full coverage and is the source of truth.

## How to resolve a creative

Every creative path stored in the DB (`meta_offline_ads`) or in
`data/creative_enriched.json` is a **relative path**. Prepend the base URL to get a
working public URL:

| Field | What it is | Example relative value | Resolved URL |
|---|---|---|---|
| `thumb` | small thumbnail | `thumbnails_med/vid_<id>_thumb.jpg` | base + value |
| `thumb_med` | **medium — use this for inline display** | `thumbnails_med/adimg_<…>.jpg` | base + value |
| `thumb_full` | full-res (**PUBLIC** — not local-only) | `fullres/adimg_<…>.jpg` | base + value |
| `video_path` | mp4 (153 videos hosted) | `videos/vid_<id>.mp4` | base + value |
| `video_thumb_path` | video poster frame | `thumbnails/vthumb_<…>.jpg` | base + value |

Organic IG/FB posts (`meta_organic_posts`): `ig_thumbnails_med/<post_id>.webp`
(1,713 hosted). Use `permalink` for the clickable post; the `.webp` for inline.

Dashboards (interactive): `index.html`, `creative_breakdown.html`,
`organic_breakdown.html` under the same base.

Embed inline with markdown so the user sees the creative:
```markdown
![ad](https://davidemasi2.github.io/tokin-ads-dashboard/thumbnails_med/vid_3920021211582453_thumb.jpg)
```

## Real vs. placeholder — ALWAYS gate on this

An ad has a **real, renderable creative iff** its `thumb_med` starts with
`thumbnails_med/`. Equivalently, in `creative_enriched.json` use the
`creative_status` field (`"real"` | `"placeholder"`).

- **719 / 721 ads are `real`.**
- **2 ads are `placeholder`** (`120239902408070484`, `120240681825830484` — both
  "Cat 1" image ads on the disabled TC1 account, with no `video_id` / `image_hash` /
  creative reference of any kind; Meta exposes only a login-gated preview iframe, so
  no static image is hostable). **Do not render the placeholder** — say "no creative
  archived for this ad" and cite copy/metrics instead.

SQL predicate:
```sql
-- only ads with a real creative
WHERE thumb_med LIKE 'thumbnails_med/%'
```

## Notes

- Provenance of the recovered set (2026-06-29 backfill of 119 previously-broken ads):
  - `thumbnails_med/vid_<id>_thumb.jpg` — 89 recovered from full-res poster frames
    already archived under `fullres/` (also hosted, ~170–270 KB).
  - `thumbnails_med/metafetch_vid_<id>.jpg` — 30 recovered via the Meta Ads MCP
    (`ads_get_ad_videos` `picture`) from the disabled TC1/TC2 accounts (160 px posters,
    real; object reads still work even though the accounts can't be insight-queried).
- 20 ads Meta returned as `fmt='image'` were actually video creatives (video-view
  insights) and were reclassified to `fmt='video'` with `video_id` populated.
- The full-res posters (`fullres/vid_<id>_thumb.jpg`) are committed and hosted — they
  are **not** local-only.
- `data/creative_enriched.json` is committed to the host repo, so any skill can fetch
  the full enriched dataset from the raw URL above with no local files.
